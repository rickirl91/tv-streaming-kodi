# -*- coding: utf-8 -*-
"""Experimental Kodi WindowXML poster wall, progressively fetching TMDb Helper folders.

Purposefully separate from StreamRow / Arctic Fuse widgets and playback settings.
Kodi WindowXML supports appending ListItems while preserving the list container.
No background collection; worker runs only while the window is open.
"""
import json
import threading
from urllib.parse import parse_qs, urlparse

import xbmc
import xbmcaddon
import xbmcgui

ADDON = xbmcaddon.Addon('script.tvstreaming.lazywall')
ROOT = ADDON.getAddonInfo('path')
ACTION_DIRECTORY = 'plugin://plugin.video.themoviedb.helper/?info=discover&tmdb_type=movie&with_genres=28&with_id=True'
# The initial safety cap is deliberately small. Raise only after confirming
# Xbox memory, poster art, selection and scroll stability.
MAX_ITEMS = 160
PREFETCH_AT = 15
ACTION_BACK = (9, 10, 92, 216, 247, 257)


def log(message, level=xbmc.LOGINFO):
    xbmc.log('[TV Lazy Wall] ' + str(message), level)


def get_remote_items(path):
    if not path.startswith('plugin://plugin.video.themoviedb.helper/'):
        raise ValueError('Unexpected plugin path')
    request = {'jsonrpc': '2.0', 'id': 1, 'method': 'Files.GetDirectory',
               'params': {'directory': path, 'media': 'files',
                          'properties': ['title', 'year', 'plot', 'thumbnail', 'fanart',
                                         'art', 'rating', 'playcount', 'uniqueid', 'imdbnumber']}}
    response = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
    if 'error' in response:
        raise RuntimeError('TMDb Helper response: ' + str(response['error']))
    return response.get('result', {}).get('files', [])


def split_page(entries):
    movies = []
    next_path = None
    for item in entries:
        path = str(item.get('file') or '')
        label = str(item.get('label') or item.get('title') or '').strip().lower()
        if 'next page' in label or 'nextpage' in label:
            if path.startswith('plugin://plugin.video.themoviedb.helper/'):
                next_path = path
            continue
        # The 'Next Page' item is a folder, but so are some movie detail items.
        # Do not accidentally treat them as pagination based on folder type.
        if path.startswith('plugin://plugin.video.themoviedb.helper/'):
            movies.append(item)
    return movies, next_path


def item_id(item):
    path = str(item.get('file') or '')
    params = parse_qs(urlparse(path).query)
    for key in ('tmdb_id', 'imdb_id', 'id'):
        value = params.get(key, [None])[0]
        if value:
            return key + ':' + str(value)
    return path


def to_list_item(entry):
    name = str(entry.get('label') or entry.get('title') or 'Movie')
    item = xbmcgui.ListItem(label=name, offscreen=True)
    art = dict(entry.get('art') or {})
    poster = art.get('poster') or entry.get('thumbnail') or art.get('thumb')
    fanart = art.get('fanart') or entry.get('fanart')
    if poster:
        art['poster'] = poster
        art.setdefault('thumb', poster)
    if fanart:
        art['fanart'] = fanart
    item.setArt(art)
    info = {'title': str(entry.get('title') or name), 'mediatype': 'movie'}
    for key in ('year', 'plot', 'rating', 'playcount'):
        if entry.get(key) is not None:
            info[key] = entry[key]
    item.setInfo('video', info)
    item.setProperty('streamrow.path', str(entry.get('file') or ''))
    item.setProperty('streamrow.label', name)
    return item


class LazyWall(xbmcgui.WindowXML):
    def onInit(self):
        self._seen = set()
        self._paths = []
        self._next_path = ACTION_DIRECTORY
        self._pending = None
        self._error = None
        self._lock = threading.Lock()
        self._thread = None
        self._closed = False
        self._loading_path = None
        self._loaded_pages = 0
        self._selected_path = None
        self._status('Loading Action Movies...')
        self.clearList()
        self.setFocusId(50)
        # Initial page is requested synchronously to populate Kodi's panel.
        # Subsequent pages are requested in a short-lived worker.
        try:
            items, next_path = split_page(get_remote_items(self._next_path))
            self._accept_page(items, next_path)
            self._try_prefetch()
        except Exception as exc:
            log('Initial load error: ' + repr(exc), xbmc.LOGERROR)
            self._status('Unable to load Action Movies. Press Back.')

    def _status(self, message):
        self.setProperty('Status', message)
        self.setProperty('Title', 'Action Movies')

    def _accept_page(self, data, next_path):
        fresh = []
        for entry in data:
            key = item_id(entry)
            if key not in self._seen:
                self._seen.add(key)
                fresh.append(to_list_item(entry))
        capacity = MAX_ITEMS - self.getListSize()
        if capacity > 0 and fresh:
            self.addItems(fresh[:capacity])
        self._loaded_pages += 1
        # Don't continue indefinitely if the source loops or returns duplicates.
        self._next_path = next_path if fresh and self.getListSize() < MAX_ITEMS else None
        if self.getListSize() >= MAX_ITEMS:
            self._status('Experimental limit: {0} posters (no pagination tile)'.format(MAX_ITEMS))
        elif self._next_path:
            self._status('{0} posters loaded · scroll down for more'.format(self.getListSize()))
        else:
            self._status('{0} posters · end of available listing'.format(self.getListSize()))
        log('Loaded page {0}; total {1}; next={2}'.format(
            self._loaded_pages, self.getListSize(), bool(self._next_path)))

    def _try_prefetch(self):
        if self._closed or not self._next_path or self._thread or self._pending or self._error:
            return
        path = self._next_path
        self._loading_path = path
        def worker():
            try:
                batch = split_page(get_remote_items(path))
                with self._lock:
                    self._pending = (path, batch)
            except Exception as exc:
                with self._lock:
                    self._error = repr(exc)
        thread = threading.Thread(target=worker, name='TVLazyWallPage')
        thread.daemon = True
        self._thread = thread
        thread.start()

    def _process_queue(self):
        pending = None
        error = None
        with self._lock:
            if self._pending:
                pending = self._pending
                self._pending = None
            if self._error:
                error = self._error
                self._error = None
        if error:
            log('Page load error: ' + error, xbmc.LOGERROR)
            self._status('Could not load next posters; go Back and reopen to retry')
            self._thread = None
            # Keep the link but do not immediately retry on every keypress.
            self._next_path = None
            return
        if pending:
            path, (data, next_path) = pending
            if path == self._loading_path:
                self._thread = None
                self._accept_page(data, next_path)

    def onAction(self, action):
        if action.getId() in ACTION_BACK:
            self._closed = True
            self.close()
            return
        if not self._closed:
            self._process_queue()
            try:
                remaining = self.getListSize() - self.getCurrentListPosition() - 1
                if remaining <= PREFETCH_AT:
                    self._try_prefetch()
            except RuntimeError:
                pass

    def onClick(self, control_id):
        if control_id != 50 or self.getListSize() == 0:
            return
        index = self.getCurrentListPosition()
        item = self.getListItem(index)
        path = item.getProperty('streamrow.path')
        if path and path.startswith('plugin://plugin.video.themoviedb.helper/'):
            # TEST PATH: close custom window and open normal Kodi/TMDb Helper
            # directory so the existing TMDb Helper movie UI controls playback.
            # Position restoration after returning is NOT implemented yet.
            self._selected_path = path
            self._closed = True
            self.close()


def main():
    # Restrict this initial experiment to the existing Arctic Fuse 3 skin.
    skin = xbmc.getInfoLabel('Skin.CurrentSkin')
    if skin and 'arctic fuse' not in skin.lower():
        xbmcgui.Dialog().ok('TV Streaming Lazy Wall',
                            'This first test targets Arctic Fuse 3. Your skin is: ' + skin)
        return
    ui = LazyWall('TVStreamingLazyWall.xml', ROOT, 'default', '1080i', True)
    try:
        ui.doModal()
        chosen = getattr(ui, '_selected_path', None)
    finally:
        del ui
    if chosen:
        # No auto-play; always hand off to the familiar TMDb Helper UI.
        xbmc.executebuiltin('ActivateWindow(Videos,"{0}",return)'.format(chosen.replace('"', '%22')))

if __name__ == '__main__':
    main()
