TV Streaming Lazy Wall — Xbox experiment 0.1.0
================================================

Standalone test only. Does NOT replace StreamRow 0.1.0, your homepage widgets,
Arctic Fuse 3, TMDb Helper, Trakt, or playback settings.

INSTALL: Settings > Add-ons > Install from zip file > rickirl91 >
script.tvstreaming.lazywall-0.1.0.zip
(or select the ZIP from a connected local source).

RUN: Add-ons > Program add-ons > TV Streaming Lazy Wall (EXPERIMENT).
The add-on opens an Action Movies wall. Scroll down:
- first 20 titles should appear immediately
- the next page should be pre-fetched and appended as you approach the end
- no blue TMDb Next Page tile should appear
- the pink focus border is read from Arctic Fuse's current focus colour
- selecting a movie exits the preview and requests its normal TMDb Helper details

VERIFY: Photograph initial wall, after more than 20 posters, and behaviour
when opening a title, returning via Back, and switching categories.

LIMITATIONS of THIS preview:
- Experiment is capped to 160 posters, not yet full indefinite browsing.
- Back from movie details does not restore wall position yet.
- Prefetch appends on the next controller navigation event (safe UI thread),
  so a rapid scroll can briefly reach the end before the next batch appears.
- The UI is a theme-colour-aware custom panel, not Arctic Fuse's native view.
- It does not modify the blue v0.1.0 See All tile yet.
- Xbox runtime and TMDb Helper pagination remain UNTESTED.

Uninstall at any time. No profile settings or playback sources are written.
