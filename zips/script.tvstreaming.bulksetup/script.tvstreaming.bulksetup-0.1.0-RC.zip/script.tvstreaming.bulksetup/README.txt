BULK WIDGETS SETUP — RC

Requires Arctic Fuse 3, StreamRow v0.3.0 RC and Lazy Wall v0.3.0 RC.

Purpose: Convert supported TMDb Helper movie/TV catalogue widget rows across
all current-profile Arctic Fuse 3 menu widget configurations, without manual
per-row editing. Uses native script.skinvariables JSON files, preserving row
order, label, style, target, icon, menu positioning and main-menu links.

On launch, choose Preview and apply. The addon counts eligible rows and shows
sample labels BEFORE any write. Confirm to create a verified backup and apply.
A Restore last backup command is available, but refuses if manual edits happened
since migration. Fully quit/reopen Kodi after applying or restoring.

Protective exclusions: Continue Watching, Up Next, in-progress TV, Trakt
watchlists/history, personalized profile rows and unsupported non-TMDb
sources are left unchanged. Dynamic $INFO expressions other than reload are
also skipped. Provider rows powered by TMDb Helper are eligible. The wall
follows TMDb Helper's own pagination; finite/non-paginated sources show only
the items their plugin returns. Existing standalone Action widget preserved.

Only current Kodi profile is modified. This is not a global multi-profile sync.

Requires real Xbox acceptance test on a dynamic row (e.g. Trending Movies)
before applying to every row on Cricky. Initial use: select Preview and review
count, then cancel if user wishes to stage further.
