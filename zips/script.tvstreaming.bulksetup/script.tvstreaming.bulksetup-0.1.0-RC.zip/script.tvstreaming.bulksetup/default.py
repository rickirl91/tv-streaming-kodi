# -*- coding: utf-8 -*-
"""Opt-in, locally executed Arctic Fuse 3 widget source migrator.

Uses the installed script.skinvariables JSON schema in the CURRENT Kodi profile.
No remote services, credentials, API keys, or background work.
"""
import base64
import copy
import datetime
import hashlib
import json
import os
import re
from urllib.parse import urlparse, parse_qs

import xbmc
import xbmcgui
import xbmcvfs

SKIN = 'skin.arctic.fuse.3'
SKIN_PREFIX = 'skinvariables-shortcut-'
BASE = 'special://profile/addon_data/script.skinvariables/nodes/'
OWN = 'special://profile/addon_data/script.tvstreaming.bulksetup/'
PROTECTED = ('continue watching', 'continuewatching', 'watching',
             'up next', 'upnext', 'in progress', 'in-progress',
             'resume', 'watchlist', 'watch history', 'history',
             'recently watched', 'progress', 'next episode', 'next up',
             'collection', 'favourites', 'favorites', 'my lists')
BLOCKED_INFO = ('play', 'details', 'seasons', 'episodes', 'videos',
                'search', 'directory', 'context', 'settings', 'nextpage')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def log(message, level=xbmc.LOGINFO):
    xbmc.log('[TV Streaming Bulk Setup] ' + str(message), level)


def read_raw(path):
    with open(path, 'rb') as f:
        return f.read()


def parse_json(data):
    return json.loads(data.decode('utf-8-sig'))


def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, indent=4) + '\n').encode('utf-8')


def encoded(source, label, media):
    record = {'url': source, 'title': label[:120], 'media': media}
    return base64.urlsafe_b64encode(
        json.dumps(record, separators=(',', ':'), ensure_ascii=False).encode('utf-8')
    ).decode('ascii').rstrip('=')


def classify(widget):
    """Return (new label,new path,reason); no network or Kodi operations."""
    if not isinstance(widget, dict):
        return None, None, 'not an object'
    path = widget.get('path', '')
    label = str(widget.get('label') or '')
    if not isinstance(path, str) or not path:
        return None, None, 'empty/non-path'
    if 'plugin.video.streamrow' in path:
        # Existing Action proof-of-concept is already working on Xbox.
        if label == 'Action — See All First':
            return 'Action Movies', path, 'rename tested Action row'
        return None, None, 'already StreamRow'
    normalized = re.sub(r'[^a-z0-9 ]', ' ', label.lower())
    normalized = re.sub(r'\s+', ' ', normalized).strip()
    if any(word in normalized for word in PROTECTED):
        return None, None, 'personal/progress row: preserved'
    parsed = urlparse(path)
    if parsed.scheme != 'plugin' or parsed.netloc != 'plugin.video.themoviedb.helper':
        return None, None, 'not a TMDb Helper catalogue'
    if parsed.path not in ('', '/'):
        return None, None, 'non-catalogue subpath'
    pairs = parsed.query.split('&')
    safe_pairs = [p for p in pairs if p and not p.startswith('reload=')]
    safe_query = '&'.join(safe_pairs)
    if '$INFO[' in safe_query or '$VAR[' in safe_query or '$ESCINFO[' in safe_query:
        return None, None, 'dynamic expression requires manual adapter'
    qs = parse_qs(safe_query)
    info = qs.get('info', [''])[0].lower()
    if not info or info in BLOCKED_INFO:
        return None, None, 'not a catalogue listing'
    media = qs.get('tmdb_type', [''])[0].lower()
    if media not in ('movie', 'tv'):
        return None, None, 'media type not explicit'
    original = 'plugin://plugin.video.themoviedb.helper/?' + safe_query
    if len(original) > 2048:
        return None, None, 'path too long'
    token = encoded(original, label, media)
    if len(token) > 4096:
        return None, None, 'token too long'
    newpath = ('plugin://plugin.video.streamrow/?mode=wrap&source=' + token
               + '&reload=$INFO[Window(Home).Property(TMDbHelper.Widgets.Reload)]')
    return label, newpath, 'catalogue: ' + media


def patch_items(value, counters, changes, breadcrumb=''):
    if not isinstance(value, list):
        raise ValueError('Widget root is not a list')
    for i, row in enumerate(value):
        if not isinstance(row, dict):
            continue
        label = str(row.get('label') or '')
        dest = breadcrumb + ' / ' + label
        newlabel, newpath, reason = classify(row)
        if newpath is not None and (newpath != row.get('path') or newlabel != label):
            old = row.get('path')
            row['path'] = newpath
            if newlabel != label:
                row['label'] = newlabel
            counters['converted'] += 1
            changes.append((dest, reason, old))
        else:
            counters['skipped'][reason] = counters['skipped'].get(reason, 0) + 1
        # Optional child widget groups are encountered on some custom hub layouts.
        # Change only actual widget entries, never main-menu or submenu actions.
        if isinstance(row.get('widgets'), list):
            patch_items(row['widgets'], counters, changes, dest)


def widget_files():
    skin_dir = xbmcvfs.translatePath(BASE + SKIN)
    if not os.path.isdir(skin_dir):
        raise IOError('Arctic Fuse widgets folder was not found in this Kodi profile')
    paths = []
    for filename in sorted(os.listdir(skin_dir)):
        if (filename.startswith(SKIN_PREFIX)
                and filename.endswith('widgets.json')
                and os.path.isfile(os.path.join(skin_dir, filename))):
            paths.append(os.path.join(skin_dir, filename))
    if not paths:
        raise IOError('No customised widget files found in this Kodi profile')
    return paths


def build_plan():
    out = []
    stats = {'converted': 0, 'skipped': {}}
    changes = []
    for path in widget_files():
        before = read_raw(path)
        try:
            data = parse_json(before)
        except (ValueError, UnicodeError) as exc:
            raise ValueError('Cannot parse ' + os.path.basename(path) + ': ' + str(exc))
        new_data = copy.deepcopy(data)
        old_total = stats['converted']
        patch_items(new_data, stats, changes, os.path.basename(path))
        if stats['converted'] > old_total:
            after = json_bytes(new_data)
            # Self-check serialized structure before exposing any Apply option.
            if parse_json(after) != new_data:
                raise ValueError('Generated widget JSON failed round-trip verification')
            out.append({'path': path, 'before': before, 'after': after})
    return out, stats, changes


def atomic_write(path, contents):
    tmp = path + '.tvbulk-pending'
    try:
        with open(tmp, 'wb') as f:
            f.write(contents)
            f.flush()
            os.fsync(f.fileno())
        if sha(read_raw(tmp)) != sha(contents):
            raise IOError('Temporary write checksum mismatch')
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)


def refresh_skin(plan):
    window = xbmcgui.Window(10000)
    for part in plan:
        basename = os.path.basename(part['path'])
        key = 'SkinVariables.ShortcutsNode.' + SKIN + '-' + basename
        window.setProperty(key, json.dumps(parse_json(read_raw(part['path'])),
                                           ensure_ascii=False, separators=(',', ':')))
    stamp = datetime.datetime.utcnow().strftime('%Y%m%dT%H%M%S')
    window.setProperty('SkinVariables.ShortcutsNode.Reload', stamp)
    log('Refreshed ' + str(len(plan)) + ' widget files')


def apply(plan, stats, changes):
    root = xbmcvfs.translatePath(OWN + 'backups/')
    os.makedirs(root, exist_ok=True)
    tag = datetime.datetime.utcnow().strftime('%Y%m%d-%H%M%S')
    folder = os.path.join(root, tag)
    os.makedirs(folder, exist_ok=False)
    records = []
    # Verify all backups before changing a SINGLE current Kodi setting.
    for part in plan:
        source, before, after = part['path'], part['before'], part['after']
        backup = os.path.join(folder, os.path.basename(source))
        with open(backup, 'wb') as f:
            f.write(before)
        if read_raw(backup) != before or read_raw(source) != before:
            raise IOError('Backup verification failed; no changes were made')
        records.append({'path': source, 'backup': backup, 'before': sha(before),
                        'after': sha(after)})
    manifest = {'created': tag, 'skin': SKIN, 'converted': stats['converted'],
                'changed_rows': [x[0] for x in changes], 'files': records}
    manifestpath = os.path.join(folder, 'manifest.json')
    with open(manifestpath, 'wb') as f:
        f.write(json_bytes(manifest))
    applied = []
    try:
        for part in plan:
            if sha(read_raw(part['path'])) != sha(part['before']):
                raise IOError('Widget changed during backup: ' + part['path'])
            atomic_write(part['path'], part['after'])
            applied.append(part)
        refresh_skin(plan)
    except Exception:
        for part in reversed(applied):
            atomic_write(part['path'], part['before'])
        refresh_skin(applied)
        raise
    return folder


def backup_records():
    root = xbmcvfs.translatePath(OWN + 'backups/')
    if not os.path.isdir(root):
        return []
    records = []
    for name in sorted(os.listdir(root), reverse=True):
        p = os.path.join(root, name, 'manifest.json')
        if os.path.isfile(p):
            records.append((name, p))
    return records


def undo():
    records = backup_records()
    if not records:
        xbmcgui.Dialog().ok('TV Streaming', 'No bulk-update backup was found.')
        return
    name, manifestpath = records[0]
    manifest = parse_json(read_raw(manifestpath))
    parts = manifest.get('files', [])
    # Restore ONLY if no one edited a widget file since this installation.
    if any(sha(read_raw(r['path'])) != r['after'] for r in parts):
        xbmcgui.Dialog().ok('TV Streaming',
                            'Some widgets have changed since this backup. Auto-restore was blocked to protect your newer edits.')
        return
    if not xbmcgui.Dialog().yesno('Restore widgets',
                                 'Restore the exact widget configuration saved on ' + name + '?'):
        return
    restored = []
    originals = []
    try:
        for rec in parts:
            original = read_raw(rec['backup'])
            if sha(original) != rec['before']:
                raise IOError('Backup integrity check failed')
            originals.append((rec['path'], original, read_raw(rec['path'])))
        for path, original, current in originals:
            atomic_write(path, original)
            restored.append({'path': path})
        refresh_skin(restored)
        # Mark consumed so repeated restore does not overwrite later user edits.
        os.rename(manifestpath, manifestpath + '.restored')
        xbmcgui.Dialog().ok('TV Streaming',
                            'Original widgets restored. Fully restart Kodi to refresh the homepage.')
    except Exception:
        for path, original, current in originals:
            if any(x['path'] == path for x in restored):
                atomic_write(path, current)
        refresh_skin(restored)
        raise


def main():
    if xbmc.getSkinDir().lower() != SKIN:
        xbmcgui.Dialog().ok('TV Streaming Bulk Setup',
            'This installer targets Arctic Fuse 3. The active skin is: ' + xbmc.getSkinDir())
        return
    try:
        import xbmcaddon
        xbmcaddon.Addon('plugin.video.streamrow')
        xbmcaddon.Addon('script.tvstreaming.lazywall')
    except Exception:
        xbmcgui.Dialog().ok('TV Streaming Bulk Setup',
            'Install StreamRow 0.3.0 RC and Lazy Wall 0.3.0 RC before applying widget changes.')
        return
    action = xbmcgui.Dialog().select('TV Streaming — Bulk setup', [
        'Preview and apply compatible catalogue rows',
        'Restore latest automatic backup',
        'Cancel'])
    if action == 1:
        undo()
        return
    if action != 0:
        return
    plan, stats, changes = build_plan()
    if not plan:
        xbmcgui.Dialog().ok('TV Streaming Bulk Setup',
            'No eligible changes found. Current settings were left untouched.')
        return
    msg = ('Convert {} widget rows across {} configuration files?\n'
           'Original order and styles are preserved.\n'
           'Continue Watching, progress, Trakt lists and unsupported sources are skipped.\n'
           'You can restore your previous settings using this add-on.').format(
                stats['converted'], len(plan))
    # Show concrete examples and require permission before writing.
    details = '\n'.join('• ' + row[0].split(' / ')[-1] for row in changes[:5])
    if not xbmcgui.Dialog().yesno('Bulk update preview', msg + '\n\n' + details):
        return
    folder = apply(plan, stats, changes)
    log('Applied ' + str(stats['converted']) + ' rows. Backup: ' + folder)
    xbmcgui.Dialog().ok('TV Streaming — Updated',
        ('Updated {} catalogue rows in {} widget files. Your original settings '
         'are backed up. Fully quit and restart Kodi to refresh the homepage.').format(
              stats['converted'], len(plan)))

if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        log('Bulk update stopped: ' + repr(exc), xbmc.LOGERROR)
        xbmcgui.Dialog().ok('TV Streaming Bulk Setup',
            'No further changes were made. Review Kodi log for details: ' + str(exc)[:200])
