# -*- coding: utf-8 -*-
"""StreamRow proof-of-concept: See All first, then Kodi TMDb Helper movie entries.

No remote API credentials, background tasks, filesystem changes, or playback code.
Metadata fidelity and nested plugin listing are deliberately tested BEFORE replacing
an existing home widget.
"""
import json
import sys
from urllib.parse import parse_qs, urlparse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

ADDON_ID = "plugin.video.streamrow"
TMDB_ID = "plugin.video.themoviedb.helper"
ACTION_DIR = (
    "plugin://plugin.video.themoviedb.helper/?"
    "info=discover&tmdb_type=movie&with_genres=28&with_id=True"
)
# Match the user's existing Action widget exactly, including widget=true.
ACTION_WIDGET = ACTION_DIR + "&widget=true&reload="
MAX_MOVIES = 30

def log(message, level=xbmc.LOGINFO):
    xbmc.log("[StreamRow] " + message, level)

def get_items():
    # Kodi's own Files.GetDirectory API delegates to TMDb Helper. On some Kodi
    # builds it does not preserve artwork/metadata; this is why we preview first.
    payload = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "Files.GetDirectory",
        "params": {
            "directory": ACTION_WIDGET,
            "media": "files",
            "properties": [
                "title", "year", "plot", "thumbnail", "fanart",
                "art", "rating", "playcount", "uniqueid", "imdbnumber"
            ],
        },
    }
    response = json.loads(xbmc.executeJSONRPC(json.dumps(payload)))
    if "error" in response:
        raise RuntimeError(str(response["error"].get("message", "Kodi JSON-RPC error")))
    return response.get("result", {}).get("files", [])

def is_pagination(entry):
    label = str(entry.get("label") or "").strip().lower()
    path = str(entry.get("file") or "")
    if label in ("next page", "nextpage", "next page >>", "next page >"):
        return True
    parsed = urlparse(path)
    query = parse_qs(parsed.query)
    info = str(query.get("info", [""])[0]).lower()
    return info in ("nextpage", "next_page")

def add_see_all(handle, icon):
    item = xbmcgui.ListItem(label="See All", offscreen=True)
    item.setArt({"poster": icon, "thumb": icon, "icon": icon})
    item.setInfo("video", {"title": "See All", "plot": "Browse the full Action Movies catalogue"})
    # This is a direct TMDb Helper folder, so the existing TMDb Helper movie
    # directory view (the tested poster wall) handles the destination.
    xbmcplugin.addDirectoryItem(handle, ACTION_DIR, item, isFolder=True)

def add_movie(handle, entry):
    path = entry.get("file", "")
    if not path or not isinstance(path, str) or not path.startswith("plugin://"):
        return False
    label = entry.get("label") or entry.get("title") or "Movie"
    artwork = entry.get("art") or {}
    if not isinstance(artwork, dict):
        artwork = {}
    thumb = entry.get("thumbnail") or artwork.get("poster") or artwork.get("thumb")
    fanart = entry.get("fanart") or artwork.get("fanart")
    if thumb:
        artwork.setdefault("poster", thumb)
        artwork.setdefault("thumb", thumb)
        artwork.setdefault("icon", thumb)
    if fanart:
        artwork.setdefault("fanart", fanart)
    item = xbmcgui.ListItem(label=str(label), offscreen=True)
    if artwork:
        item.setArt(artwork)
    info = {"title": str(entry.get("title") or label), "mediatype": "movie"}
    for field in ("year", "plot", "playcount", "rating"):
        if entry.get(field) is not None:
            info[field] = entry[field]
    item.setInfo("video", info)
    ids = entry.get("uniqueid")
    if not isinstance(ids, dict):
        ids = {}
    if entry.get("imdbnumber"):
        ids["imdb"] = entry["imdbnumber"]
    if not ids:
        tmdb_id = parse_qs(urlparse(path).query).get("tmdb_id", [None])[0]
        if tmdb_id:
            ids["tmdb"] = str(tmdb_id)
    if ids:
        try:
            item.getVideoInfoTag().setUniqueIDs({str(k): str(v) for k, v in ids.items()})
        except (AttributeError, TypeError, ValueError):
            pass
    is_folder = entry.get("filetype") == "directory"
    if not is_folder:
        item.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(handle, path, item, isFolder=is_folder)
    return True

def listing(handle):
    icon = xbmcaddon.Addon(ADDON_ID).getAddonInfo("path") + "/resources/media/see_all.png"
    xbmcplugin.setContent(handle, "movies")
    add_see_all(handle, icon)
    try:
        entries = get_items()
        movies = [x for x in entries if not is_pagination(x)]
        movie_count = 0
        posters = 0
        for entry in movies:
            if movie_count >= MAX_MOVIES:
                break
            art = entry.get("art") or {}
            if not isinstance(art, dict):
                art = {}
            if entry.get("thumbnail") or art.get("poster") or art.get("thumb"):
                posters += 1
            if add_movie(handle, entry):
                movie_count += 1
        log("Fetched {0} entries; displayed {1} movies; artwork on {2}".format(
            len(entries), movie_count, posters))
        if movie_count < 5 or posters < max(3, movie_count // 2):
            label = "[TEST NOT PASSED] Kodi did not return enough movie posters"
            status = xbmcgui.ListItem(label=label, offscreen=True)
            status.setArt({"icon": "DefaultWarning.png"})
            xbmcplugin.addDirectoryItem(handle, ACTION_DIR, status, isFolder=True)
            log("Do not replace the existing Action widget: missing metadata", xbmc.LOGWARNING)
    except Exception as exc:
        log("Preview failed: " + repr(exc), xbmc.LOGERROR)
        item = xbmcgui.ListItem(label="[TEST NOT PASSED] Could not retrieve Action movie list")
        item.setArt({"icon": "DefaultWarning.png"})
        xbmcplugin.addDirectoryItem(handle, ACTION_DIR, item, isFolder=True)
    finally:
        xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)

def home(handle, base):
    xbmcplugin.setContent(handle, "files")
    item = xbmcgui.ListItem(label="Action - See All First (test)")
    xbmcplugin.addDirectoryItem(handle, base + "?mode=action", item, isFolder=True)
    xbmcplugin.endOfDirectory(handle)

if __name__ == "__main__":
    base = sys.argv[0]
    handle = int(sys.argv[1])
    query = parse_qs(sys.argv[2].lstrip("?")) if len(sys.argv) > 2 else {}
    if query.get("mode", [""])[0] == "action":
        listing(handle)
    else:
        home(handle, base)
