TV Streaming StreamRow v0.2.0 — consolidated release candidate

Requires TV Streaming Lazy Wall v0.2.0 (included dependency in our repo).
Select the Video add-on, then Action — See All First. Tile one will
attempt to open the scroll-loading wall; other 20 posters remain Kodi items.

This folder-launch handoff has NOT yet passed an Xbox test. Keep your existing
Action widget unchanged until both tile and movie Play tests pass.

See All artwork is neutral and inherits Arctic Fuse focus highlighting. Actual
pixel recolouring of the poster based on Miami requires changing the skin,
so this package avoids claiming full live palette inheritance.

Other genres are exposed for future rollout without rebuilding code.


v0.2.1 RC: replaced fixed blue See All poster with a neutral charcoal tile.
Arctic Fuse supplies the currently selected focus colour to its poster frame.
This is theme-compatible but the tile interior is intentionally neutral.


0.2.2 Xbox See All click repair:
- Treat See All as a non-playable action callback, not as a directory.
- Use RunAddon to hand off to Lazy Wall by category; avoid failed endOfDirectory.
- Context-menu fallback: Open Full Wall (direct) if Kodi still intercepts select.
- This is a targeted integration change only; movie artwork, widgets and
  the separate v0.2.1 Lazy Wall build are otherwise unchanged.


0.2.3: neutral artwork (charcoal/white) in place of the navy/lavender See All
image. Active Arctic Fuse 3/Miami skin still provides focus selection colour.
No change to Kodi list item type, direct launch callback, movie source
selection, wall content, Trakt, or on-Xbox profiles.


v0.2.4 RC — ARTWORK CACHE-BUST FIX
Kodi texture caching kept displaying the obsolete blue See All icon in v0.2.3.
The existing fully grayscale Inter Bold / charcoal poster has a new physical filename, see_all_miami_neutral_v024.png.
No changes to video list, See All click, context fallback, Lazy Wall, Trakt or player settings.
Selecting the tile still gets the Miami pink border from Arctic Fuse.
