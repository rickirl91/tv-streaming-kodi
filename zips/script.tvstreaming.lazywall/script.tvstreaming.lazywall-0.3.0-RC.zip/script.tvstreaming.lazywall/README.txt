TV Streaming Lazy Wall v0.2.0 — consolidated release candidate

Adds bounded rolling window (approximately 200 Kodi posters), category switching,
a custom details popup with Play, and position retention after details.

Install then open Program add-ons > TV Streaming Lazy Wall. Action is the default.
The addon can be launched with RunScript(script.tvstreaming.lazywall,category=action).

Movies: Play uses TMDbHelper documented player function, retaining existing
player providers and defaults. TV: Browse episodes opens the TMDbHelper seasons
folder; custom TV seasons are not yet included in this release candidate.

The wall is unbounded by our addon, but TMDb may impose an upstream limit.
No credential changes, no background crawls, no skin modifications.

The first-row See All launch via the StreamRow video plugin is not yet Xbox
validated. Keep the existing stable widget until the complete workflow passes.
Rollback: reinstall v0.1.4.


v0.2.2 RC: Fix trailer hidden behind details popup and position reset.
Close dialog before starting YouTube; wait for playback to finish, restore
the same title's details and keep Lazy Wall onInit idempotent across Kodi
window reactivation. This is an Xbox acceptance candidate; do not replace
the working homepage widget until verified. Source built from the available
v0.2.0 consolidated baseline with v0.2.1 details styling reconstructed.

v0.3.0 RC (generic TMDb Helper catalogue source): Accepts a safe base64url
metadata token as "source=" from StreamRow v0.3.0. Uses the original widget's
TMDb Helper catalogue path, media type and label, then follows its real Next
page path with the existing 200-item rolling memory window. Previous category
launcher remains unchanged for previously tested Action, Comedy, etc.
No current-profile settings are changed by this add-on.
