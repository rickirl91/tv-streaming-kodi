TV Streaming Lazy Wall v0.2.0 — consolidated release candidate

Adds bounded rolling window (approximately 200 Kodi posters), category switching,
a custom details popup with Play, and position retention after details.

Install then open Program add-ons > TV Streaming Lazy Wall. Action is the default.
The addon can be launched with RunScript(script.tvstreaming.lazywall,category=action).

Movies: Play uses TMDbHelper documented player function, retaining existing
player providers and defaults. TV: Browse episodes opens the TMDbHelper seasons
folder; custom TV seasons are not yet included in this release candidate.

The wall is unbounded by our addon, but TMDb may impose an upstream limit.
No credential changes, no background crawls, no skin modifications.

The first-row See All launch via the StreamRow video plugin is not yet Xbox
validated. Keep the existing stable widget until the complete workflow passes.
Rollback: reinstall v0.1.4.

Details: Watch Trailer requests the selected movie/show's video metadata through
TMDb Helper, and plays the official trailer with the Kodi YouTube add-on
when available. No additional API keys or account linkage are needed.
No trailer or missing YouTube player displays a clear message.

Requires Xbox acceptance testing before replacing the working widget.


v0.2.1 RC visual correction: opaque dark details screen / matte synopsis panel;
plain metadata title without Kodi COLOR/B/I markup; film rating hidden if missing;
Miami focus colour inherited from Arctic Fuse. Wall browsing/rolling window,
trailer and Play behaviour are unchanged. This visual change needs Xbox review.
