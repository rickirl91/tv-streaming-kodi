TV STREAMING — ARCTIC FUSE 3 STANDARD PRESET v0.2.1
=========================================================

This file is a REAL KODI VIDEO ADD-ON ZIP, not a skin replacement.
It contains an Arctic Fuse 3 profile navigation preset plus a browsable
catalogue of 100+ category entries and a non-destructive restore option.

BUILT FROM OUR CUSTOM DESIGN
Home | Streaming Services | Movies | TV Shows | Documentaries | [calendar] Trakt - Upcoming Episodes
- Movies and TV have extensive Netflix-style grouped categories.
- Streaming Services has separate Movies and TV listings for each provider.
- Personalised rows use your existing Trakt connection via TMDb Helper.
- Kids profile and Miami Vaporwave/Purple appearance are NOT modified.
- Not organised from Stremio / My Lists; their list export is NOT bundled.

INSTALLATION ON THE XBOX (once only)
1. Put the ZIP somewhere Kodi on Xbox can access (network share / USB file source).
   Do NOT extract it first.
2. In Kodi, switch to your PIN-protected STANDARD profile.
3. Make sure Arctic Fuse 3, TMDb Helper, and Skin Variables are enabled.
4. Kodi Settings > Add-ons > Install from zip file. Choose this ZIP.
   Kodi may ask you to enable Unknown sources for ZIP add-ons.
5. Add-ons > Video add-ons > TV Streaming Catalogue & Preset.
6. Select 'Install / Update Standard Arctic Fuse 3 Preset', accept backup prompt.
7. Kodi reloads the skin. If necessary use skin's shortcut/widget rebuild action.

You can browse the extensive hierarchy directly through the video add-on
or through hub submenu entries.

SAFETY
- Current Kodi PROFILE only, using special://profile.
- Creates a complete timestamped backup of each replaced navigation JSON
  before writing. Undo: open the add-on and choose Restore Latest Backup.
- Does NOT alter theme settings, library DB, content providers, passwords,
  logins, playback services, or Kodi profile configuration.
- If you have already customised the Standard navigation, the preset does
  REPLACE the selected 14 hub and widget JSON files for that profile.
- It does NOT rename/create profiles or set a Kids PIN. Do that separately.

CAVEATS
- The package has been syntax/schema-checked offline, not tested on your Xbox.
- Arctic Fuse 3 and TMDb Helper versions vary. One Xbox test is required.
- Provider discovery is filtered to Ireland, subscription catalogues, and
  excludes TMDb Family/Kids genre tags as a best-effort adult-profile filter.
  Misclassified family titles can still appear in generic trending/provider rows.
  It does not prove that a title is licensed to you or playable via Kodi.
- Paramount+ ID 531 may be outdated in TMDb for IE. It is left labelled
  as provisional; use the built-in 'All Streaming Providers' directory to
  find the current provider listing if the Paramount rows appear empty.
- The 'Recently Released on Netflix' feed sorts by cinema release date,
  NOT date added to streaming. Do not confuse it with a true digital premiere feed.
- Accurate 'Just Released on Streaming', 'Fresh from Cinemas' and 'New Seasons'
  smart feeds, fine-grained genres (e.g. Spy/Martial Arts), and awards
  require additional verified curated lists / data and are not misrepresented.
- You can run without Real-Debrid or other premium debrid services. This
  package adds navigation ONLY; it does not configure any playback source.

ROLLBACK
Open Video add-ons > TV Streaming Catalogue & Preset > Restore Latest Backup.

TECHNICAL FILES
Kodi user node directory (current profile):
  special://profile/addon_data/script.skinvariables/nodes/skin.arctic.fuse.3/

Source references:
- https://github.com/jurialmunkey/skin.arctic.fuse.3/tree/piers/shortcuts/presets/tmdbhelper
- https://github.com/jurialmunkey/script.skinvariables
- https://github.com/jurialmunkey/plugin.video.themoviedb.helper

No third-party code is copied into this add-on. It uses public Kodi
plugin paths and a custom Python 3 add-on using Kodi's public API.


VERSION 0.2.0
- My Lists & Trakt is placed first among custom hubs, immediately after Home.
- Arctic Fuse 3 only provides four labelled custom left-side hub positions; Streaming Services remains available via its right-hand hub control and Home submenu.
- Search now has a third source for People & Filmographies (TMDb).
- TV adds New & Upcoming Series as an extra widget.
- Documentary genre widgets use with_id=True to match working genre filters.
- Prime Video and Apple TV+ homepage widgets now target subscription series rather than empty movie results. Provider movie browsing is retained.
- Adds an explicit Rebuild Shortcuts & Widgets action.
- Always back up the current profile before applying. Test all affected sources on Xbox.

VERSION 0.2.1 — HORIZONTAL NAVIGATION TIDY-UP
- Streaming Services is the first labelled hub after Home; Movies, TV Shows, and Documentaries follow.
- Trakt is moved to the right-hand icon group with the skin's calendar icon.
- The right-hand hub is labelled "Trakt - Upcoming Episodes" but retains ALL existing Trakt widgets (Continue Watching, Up Next, Watchlist, Recommendations) and its four browsing menus.
- Search, categories, widget URLs, login, playback, skin appearance and Kids profile are unchanged.
- Apply from the PIN-protected adult profile and use Rebuild Shortcuts & Widgets if the old layout remains cached.
- Rollback: Restore Latest Backup in the installed video add-on.

VERSION 0.2.2 - STREAMING SERVICES PAIRED MOVIES AND SERIES
- 12 rows: Netflix Movies/Series; Disney+ Movies/Series; Prime Video Movies/Series; Apple TV+ Movies/Series; Paramount+ Movies/Series; HBO Max Movies/Series.
- The Prime Video Ireland query now ORs its standard, regional, ad-supported and free variants (TMDb IDs 9/119/2100/613) and permits subscription/ads/free access types; it excludes rent/buy-only titles.
- All provider browse menu entries have matching queries and movie/series labelling.
- Kodi streaming provider availability is supplied by TMDb and can be missing/stale; a populated category is not a playback guarantee.
- Other hubs, Trakt, Search, skin preferences, account settings, and Kids profile are untouched.
- This is an offline-validated pilot; the 12 Kodi widgets must be verified on Xbox.


v0.2.3 OPTIONAL PLAYBACK LINK
- New menu entry: Connect TMDb Movies Playback (optional).
- Requires TMDb Helper + TMDb Movies already installed in adult Kodi profile.
- Only installs tvstreaming.tmdbmovies.json under TMDb Helper players for the current Kodi profile.
- Does NOT change default player or preset/navigation. On-screen prompt required.
- Existing same-name file backed up before replacement, rollback on errors.
- Uses TMDb Movies upstream tmdb_resolve routes; playback must be Xbox-tested.
