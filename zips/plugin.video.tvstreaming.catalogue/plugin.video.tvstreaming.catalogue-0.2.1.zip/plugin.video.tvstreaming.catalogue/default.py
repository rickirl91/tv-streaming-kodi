# -*- coding: utf-8 -*-
"""Kodi 20+ Python 3 plugin. Zero dependencies beyond Kodi core.
Installs only Skin Variables user-node JSON for the current Kodi profile.
No network requests, no user credentials and no Kodi database modification.
"""
import sys, os, json, datetime, time
from urllib.parse import parse_qs, urlencode
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs

ADDON_ID = 'plugin.video.tvstreaming.catalogue'
SKIN_ID = 'skin.arctic.fuse.3'
BASE = 'special://profile/addon_data/script.skinvariables/nodes/' + SKIN_ID + '/'
DATA = 'special://profile/addon_data/' + ADDON_ID + '/'
ADDON = xbmcaddon.Addon(ADDON_ID)
BASEURL = sys.argv[0]
HANDLE = int(sys.argv[1])
ARGS = {k: v[-1] for k, v in parse_qs(sys.argv[2].lstrip('?')).items()}
DIALOG = xbmcgui.Dialog()

def vf_read(path):
    fh = xbmcvfs.File(path, 'r')
    try: return fh.read()
    finally: fh.close()

def vf_write(path, value):
    fh = xbmcvfs.File(path, 'w')
    try:
        result = fh.write(value)
        if result is False: raise IOError('Write failed: '+path)
    finally: fh.close()

def json_load(path): return json.loads(vf_read(path))

def json_save(path, data): vf_write(path, json.dumps(data, ensure_ascii=False, indent=2)+'\n')

def path_for(section=None,group=None,action=None):
    params = {}
    if section: params['section']=section
    if group: params['group']=group
    if action: params['action']=action
    return BASEURL+'?'+urlencode(params)

def item(label, path, folder=True, plot=''):
    li=xbmcgui.ListItem(label=label)
    li.setInfo('video',{'title':label,'plot':plot})
    xbmcplugin.addDirectoryItem(HANDLE, path, li, isFolder=folder)

def catalogue():
    return json_load(os.path.join(ADDON.getAddonInfo('path'),'resources','catalogue.json'))

def read_preset():
    folder=os.path.join(ADDON.getAddonInfo('path'),'resources','preset')
    names=sorted(x for x in os.listdir(folder) if x.startswith('skinvariables-shortcut-') and x.endswith('.json'))
    return {name:os.path.join(folder,name) for name in names}

def rebuild_shortcuts():
    """Ask the installed Arctic Fuse 3 Skin Variables generator to rebuild shortcuts.
    User can call this explicitly after a preset update. Never touches profile data.
    """
    if xbmc.getSkinDir() != SKIN_ID:
        DIALOG.ok('Arctic Fuse 3 required','Switch to Arctic Fuse 3 before rebuilding.')
        return
    xbmc.executebuiltin('SetProperty(SkinVariables.ShortcutsNode.Reload,%s,Home)' % int(time.time()))
    xbmc.executebuiltin('RunScript(script.skinvariables,run_executebuiltin=special://skin/shortcuts/skinvariables-build-templates.json,use_rules)')
    DIALOG.ok('Rebuild requested','Arctic Fuse 3 shortcut regeneration has been requested. Return to Home. If the old layout remains, close Kodi fully and reopen it.')

def refresh_skin():
    try:
        xbmc.executebuiltin('SetProperty(SkinVariables.ShortcutsNode.Reload,%s,Home)' % int(time.time()))
    except Exception as e:
        xbmc.log('TV Streaming preset reload property error: '+str(e), xbmc.LOGWARNING)
    try:
        xbmc.executebuiltin('ReloadSkin()')
    except Exception as e:
        xbmc.log('TV Streaming preset ReloadSkin error: '+str(e), xbmc.LOGWARNING)

def apply_preset():
    profile=xbmc.getInfoLabel('System.ProfileName') or 'current profile'
    if profile.strip().lower() in ('kids','kid','children','child'):
        DIALOG.ok('Kids profile protected','This preset is adult-oriented. Switch to Standard first. Nothing changed.')
        return
    if xbmc.getSkinDir() != SKIN_ID:
        DIALOG.ok('Arctic Fuse 3 required','Switch to Arctic Fuse 3 first. Nothing has been changed.')
        return
    try:
        xbmcaddon.Addon('script.skinvariables')
        xbmcaddon.Addon('plugin.video.themoviedb.helper')
    except Exception:
        DIALOG.ok('Dependency missing','Install/enable Skin Variables and TMDb Helper before applying. Nothing changed.')
        return
    msg=('CURRENT KODI PROFILE: %s\n\n'
         'Apply the Standard-profile preset only after opening Standard. '
         'The preset replaces 14 navigation/widget JSON files in this profile. '
         'A backup of each previous file will be created before any are changed. '
         'Skin theme, accounts, add-ons and playback settings are not modified.') % profile
    if not DIALOG.yesno('Install Standard streaming preset?',msg,yeslabel='Back up + apply',nolabel='Cancel'):
        return
    sources=read_preset()
    timestamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    bdir=DATA+'backups/'+timestamp+'/'
    if xbmcvfs.exists(bdir): bdir=DATA+'backups/'+timestamp+'_'+str(int(time.time()))+'/'
    xbmcvfs.mkdirs(bdir)
    xbmcvfs.mkdirs(BASE)
    manifest={'profile':profile,'created_utc':timestamp,'skin':SKIN_ID,'files':{},'source_version':'0.2.1'}
    try:
        for fn in sources:
            dest=BASE+fn
            existed=bool(xbmcvfs.exists(dest))
            manifest['files'][fn]={'existed':existed}
            if existed:
                if not xbmcvfs.copy(dest,bdir+fn): raise IOError('Could not back up '+fn)
        json_save(bdir+'manifest.json',manifest)
        if not xbmcvfs.exists(bdir+'manifest.json'):
            raise IOError('Failed to write backup manifest')
    except Exception as e:
        DIALOG.ok('Backup failed — nothing changed','Unable to create a complete backup: '+str(e))
        return
    changed=[]
    try:
        for fn,src in sources.items():
            newdata=vf_read(src)
            json.loads(newdata)  # Ensure payload is valid JSON before writing.
            dest=BASE+fn
            vf_write(dest,newdata)
            json.loads(vf_read(dest)) # Verify after write.
            changed.append(fn)
    except Exception as e:
        # Roll back every target, including a partially written failing file.
        for fn, rec in manifest['files'].items():
            target=BASE+fn
            try:
                if rec['existed']: vf_write(target,vf_read(bdir+fn))
                elif xbmcvfs.exists(target): xbmcvfs.delete(target)
            except Exception as ee:
                xbmc.log('TV Streaming rollback error '+fn+': '+str(ee),xbmc.LOGERROR)
        DIALOG.ok('Install failed — rollback attempted','Error: '+str(e)+'\nReview the Kodi log if some files did not restore.')
        return
    DIALOG.ok('Preset installed','Installed %d navigation/widget files for profile: %s.\nThe skin will reload. If widgets stay unchanged, reopen this add-on and use Rebuild Shortcuts & Widgets.'%(len(changed),profile))
    refresh_skin()

def last_backup():
    parent=DATA+'backups/'
    if not xbmcvfs.exists(parent): return None
    folders=xbmcvfs.listdir(parent)[0]
    for folder in sorted(folders,reverse=True):
        path=parent+folder+'/'; mf=path+'manifest.json'
        if xbmcvfs.exists(mf): return path,json_load(mf)
    return None

def restore():
    res=last_backup()
    if not res:
        DIALOG.ok('No backup available','No previous preset backup was found for this profile.')
        return
    bdir,manifest=res
    if not DIALOG.yesno('Restore previous layout?',
        'This restores the latest backed-up navigation for the CURRENT profile.\nBackup: '+manifest['created_utc'],
        yeslabel='Restore',nolabel='Cancel'):
        return
    try:
        for fn,rec in manifest['files'].items():
            dest=BASE+fn
            if rec['existed']:
                vf_write(dest,vf_read(bdir+fn))
                if vf_read(dest) != vf_read(bdir+fn): raise IOError('Could not verify restoration '+fn)
            elif xbmcvfs.exists(dest):
                if not xbmcvfs.delete(dest): raise IOError('Could not remove '+fn)
    except Exception as e:
        DIALOG.ok('Restore incomplete','Error: '+str(e)+'\nPlease check the Kodi log.')
        return
    DIALOG.ok('Previous layout restored','Skin reload will now be requested.')
    refresh_skin()

def show():
    data=catalogue()
    section_id=ARGS.get('section')
    group_id=ARGS.get('group')
    sections={s['id']:s for s in data['sections']}
    if not section_id:
        xbmcplugin.setPluginCategory(HANDLE,'TV Streaming Catalogue')
        for s in data['sections']:
            item(s['title'],path_for(section=s['id']))
        item('Install / Update Standard Arctic Fuse 3 Preset',path_for(action='install'),False)
        item('Rebuild Arctic Fuse 3 Shortcuts & Widgets',path_for(action='rebuild'),False)
        item('Restore Latest Backup',path_for(action='restore'),False)
    elif section_id not in sections:
        DIALOG.ok('Unknown section',section_id)
    else:
        section=sections[section_id]
        groups={g['id']:g for g in section['groups']}
        xbmcplugin.setPluginCategory(HANDLE,section['title'])
        if not group_id:
            for g in section['groups']:
                item(g['title'],path_for(section_id,g['id']))
        elif group_id in groups:
            for entry in groups[group_id]['items']:
                item(entry['title'],entry['path'],True)
        else:
            DIALOG.ok('Unknown category',group_id)
    xbmcplugin.setContent(HANDLE,'files')
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)

try:
    action=ARGS.get('action')
    if action=='install':
        apply_preset()
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)
    elif action=='rebuild':
        rebuild_shortcuts()
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)
    elif action=='restore':
        restore()
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)
    else: show()
except Exception as exc:
    xbmc.log('TV Streaming catalogue error: '+str(exc),xbmc.LOGERROR)
    DIALOG.ok('TV Streaming Catalogue error',str(exc))
    xbmcplugin.endOfDirectory(HANDLE,succeeded=False,cacheToDisc=False)
