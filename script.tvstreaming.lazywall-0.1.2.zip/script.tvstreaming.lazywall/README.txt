TV Streaming Lazy Wall — Xbox experiment 0.1.2
================================================

FIX IN 0.1.2: use Kodi getSkinDir() instead of the invalid Skin.CurrentSkin InfoLabel.\nThis addresses the false unsupported-skin pop-up on Arctic Fuse 3.5.7.\nThe scrolling wall remains an experimental test.\n\nStandalone test only. Does NOT replace StreamRow 0.1.2, your homepage widgets,
Arctic Fuse 3, TMDb Helper, Trakt, or playback settings.

INSTALL: Settings > Add-ons > Install from zip file > rickirl91 >
script.tvstreaming.lazywall-0.1.2.zip
(or select the ZIP from a connected local source).

RUN: Add-ons > Program add-ons > TV Streaming Lazy Wall (EXPERIMENT).
The add-on opens an Action Movies wall. Scroll down:
- first 20 titles should appear immediately
- the next page should be pre-fetched and appended as you approach the end
- no blue TMDb Next Page tile should appear
- the pink focus border is read from Arctic Fuse's current focus colour
- selecting a movie exits the preview and requests its normal TMDb Helper details

VERIFY: Photograph initial wall, after more than 20 posters, and behaviour
when opening a title, returning via Back, and switching categories.

LIMITATIONS of THIS preview:
- Experiment is capped to 160 posters, not yet full indefinite browsing.
- Back from movie details does not restore wall position yet.
- Prefetch appends on the next controller navigation event (safe UI thread),
  so a rapid scroll can briefly reach the end before the next batch appears.
- The UI is a theme-colour-aware custom panel, not Arctic Fuse's native view.
- It does not modify the blue v0.1.2 See All tile yet.
- Xbox runtime and TMDb Helper pagination remain UNTESTED.

Uninstall at any time. No profile settings or playback sources are written.


FIX IN 0.1.2:
- Explicit non-media XML window and Kodi panel id 100, with ControlList.addItems.
- Addresses Xbox result where loading counter advanced 20 to 39 but all poster tiles were invisible.
- Focused poster displays a short title label as diagnostic fallback.
- The underlying TMDb pagination, separate current homepage, StreamRow, and players are unchanged.
- If posters appear, test scroll to 60+ titles; do not replace the homepage yet.
